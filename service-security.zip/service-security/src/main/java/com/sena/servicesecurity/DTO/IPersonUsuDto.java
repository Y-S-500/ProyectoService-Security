package com.sena.servicesecurity.DTO;

public interface IPersonUsuDto extends IGenericDto{
	   String getAddress();
	   String getDateOfBirth();
	   String getEmail();
	   String getFirstName();
	   String getGender();
	   String getLastName();
	   String getPhone();
}
