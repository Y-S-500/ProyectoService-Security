package com.sena.servicesecurity.IRepository;

import org.springframework.stereotype.Repository;

import com.sena.servicesecurity.Entity.UserRole;

@Repository
public interface IUserRoleRepository extends IBaseRepository<UserRole, Long>{

}
