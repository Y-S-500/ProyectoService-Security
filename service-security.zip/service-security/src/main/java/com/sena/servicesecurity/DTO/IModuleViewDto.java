package com.sena.servicesecurity.DTO;

public interface IModuleViewDto extends IListDto {
	 String getName();
	    String getDescription();

	String getRoute();
	 
}
