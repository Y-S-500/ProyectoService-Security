package com.sena.servicesecurity.DTO;

public interface IUserDto extends IListDto {

	
	String getPrimerNombre();
	String getSegundoNombre();
	String getEmail();
	
}
