package com.sena.servicesecurity.IRepository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.sena.servicesecurity.DTO.IListDto;
import com.sena.servicesecurity.Entity.Role;

@Repository
public interface IRoleRepository extends IBaseRepository<Role, Long>{

	@Query(value = " SELECT "
			+ "	id,"
			+ " state, "
			+ "	name as role,"
			+ " description "
			+ "	FROM "
			+ "	role "
			+ "	WHERE "
			+ " deleted_at IS NULL", nativeQuery = true)
	List<Object[]> getList();

}
