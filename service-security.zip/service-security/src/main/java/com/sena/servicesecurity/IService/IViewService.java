package com.sena.servicesecurity.IService;

import com.sena.servicesecurity.Entity.View;

public interface IViewService extends IBaseService<View>{

}
