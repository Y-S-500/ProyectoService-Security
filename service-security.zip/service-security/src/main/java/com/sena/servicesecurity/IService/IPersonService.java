package com.sena.servicesecurity.IService;

import com.sena.servicesecurity.Entity.Person;

public interface IPersonService extends IBaseService<Person>{

}
