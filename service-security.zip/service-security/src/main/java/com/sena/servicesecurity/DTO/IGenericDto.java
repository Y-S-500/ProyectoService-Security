package com.sena.servicesecurity.DTO;

public interface IGenericDto {

	
	Long getId();
    Boolean getState();
    String getName();
    String getDescription();
    String getRoute();
    String getModule();
}
