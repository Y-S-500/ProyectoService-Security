package com.sena.servicesecurity.DTO;

public interface IRoleDto extends IListDto  {

	
	 String getName();
	    String getDescription();


}
