package com.sena.servicesecurity.IRepository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.sena.servicesecurity.Entity.View;

@Repository
public interface IViewRepository extends IBaseRepository<View, Long>{

	

	  @Query(value = "SELECT "
	            + "	id,"
	            + "	state, "
	            + "	name AS view,"
	            + "	description, "
	            + "	route "
	            + "FROM "
	            + "	view "
	            + "WHERE "
	            + "	deleted_at IS NULL", nativeQuery = true)
	List<Object[]> getList();

}
