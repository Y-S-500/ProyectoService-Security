package com.sena.servicesecurity.IService;

import com.sena.servicesecurity.Entity.Role;

public interface IRoleService extends IBaseService<Role>{

}
