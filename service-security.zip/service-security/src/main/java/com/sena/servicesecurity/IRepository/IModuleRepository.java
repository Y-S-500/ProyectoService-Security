package com.sena.servicesecurity.IRepository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.sena.servicesecurity.Entity.Module;

@Repository
public interface IModuleRepository extends IBaseRepository<Module, Long>{

	
	  @Query(value = "SELECT "
	            + "	id,"
	            + "	state, "
	            + "	name AS module,"
	            + "	description, "
	            + "	route "
	            + "FROM "
	            + "	module "
	            + "WHERE "
	            + "	deleted_at IS NULL", nativeQuery = true)
	    List<Object[]> getListD();
}
