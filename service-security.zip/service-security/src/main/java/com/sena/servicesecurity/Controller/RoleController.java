package com.sena.servicesecurity.Controller;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sena.servicesecurity.DTO.ApiResponseDto;
import com.sena.servicesecurity.DTO.IListDto;
import com.sena.servicesecurity.Entity.Role;
import com.sena.servicesecurity.IService.IRoleService;
import com.sena.servicesecurity.Service.ModuleService;
import com.sena.servicesecurity.Service.RoleService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("v1/api/role")
public class RoleController extends ABaseController<Role,IRoleService>{
	public RoleController(IRoleService service) {
        super(service, "Role");
    }
/*
	  @GetMapping("/list")
	    public ResponseEntity<String> show() {
	        try {
	            List<Object[]> entities = service.getListD();
	            List<IListDto> dtos = ((RoleService) service).convertToIGenericDto(entities);
	            String jsonResponse = filterNullProperties(dtos);

	            return ResponseEntity.ok(jsonResponse);
	        } catch (Exception e) {
	            return ResponseEntity.internalServerError().body(e.getMessage());
	        }
	    }
	// Método para filtrar las propiedades nulas antes de la serialización del objeto JSON
	  public static String filterNullProperties(List<?> objects) throws JsonProcessingException {
	      ObjectMapper mapper = new ObjectMapper();
	      mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
	      return mapper.writeValueAsString(objects);
	  }

*/
	   
		@GetMapping("/list")
		public ResponseEntity<ApiResponseDto<List<IListDto>>> show() {
		    try {
		        List<Object[]> entities = service.getListD();
		        List<IListDto> dtos = ((RoleService) service).convertToIGenericDto(entities);
		        return ResponseEntity.ok(new ApiResponseDto<>("Registros encontrados", dtos, true));
		    } catch (Exception e) {
		        return ResponseEntity.internalServerError().body(new ApiResponseDto<>(e.getMessage(), null, false));
		    }
		}




}
