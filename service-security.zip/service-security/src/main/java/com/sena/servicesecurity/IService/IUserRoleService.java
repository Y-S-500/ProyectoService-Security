package com.sena.servicesecurity.IService;

import com.sena.servicesecurity.Entity.UserRole;

public interface IUserRoleService extends IBaseService<UserRole>{

}
