package com.sena.servicesecurity.DTO;

import com.fasterxml.jackson.annotation.JsonInclude;

public interface IListDto {
	
	     Long getId();
	    Boolean getState();
		
	   
		
		 
	    
	
	

}
