package com.sena.servicesecurity.Controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sena.servicesecurity.DTO.ApiResponseDto;
import com.sena.servicesecurity.DTO.IListDto;
import com.sena.servicesecurity.Entity.Module;
import com.sena.servicesecurity.IService.IModuleService;
import com.sena.servicesecurity.Service.ModuleService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("v1/api/module")
public class ModuleController extends ABaseController<Module,IModuleService>{
	public ModuleController(IModuleService service) {
        super(service, "Module");
    }
	

	   
	@GetMapping("/list")
	public ResponseEntity<ApiResponseDto<List<IListDto>>> show() {
	    try {
	        List<Object[]> entities = service.getListD();
	        List<IListDto> dtos = ((ModuleService) service).convertToIGenericDto(entities);
	        return ResponseEntity.ok(new ApiResponseDto<>("Registros encontrados", dtos, true));
	    } catch (Exception e) {
	        return ResponseEntity.internalServerError().body(new ApiResponseDto<>(e.getMessage(), null, false));
	    }
	}

}
