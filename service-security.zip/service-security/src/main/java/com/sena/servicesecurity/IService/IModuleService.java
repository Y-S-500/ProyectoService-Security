package com.sena.servicesecurity.IService;

import java.util.List;

import com.sena.servicesecurity.Entity.Module;

public interface IModuleService extends IBaseService<Module>{

	 List<Object[]> getListD() throws Exception;
}
