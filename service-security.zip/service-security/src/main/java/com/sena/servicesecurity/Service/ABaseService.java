package com.sena.servicesecurity.Service;
import com.fasterxml.jackson.annotation.JsonInclude;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sena.servicesecurity.DTO.IGenericDto;
import com.sena.servicesecurity.DTO.IListDto;
import com.sena.servicesecurity.DTO.IModuleViewDto;
import com.sena.servicesecurity.DTO.IPersonDto;
import com.sena.servicesecurity.DTO.IPersonUsuDto;
import com.sena.servicesecurity.DTO.IRoleDto;
import com.sena.servicesecurity.DTO.IUserDto;
import com.sena.servicesecurity.Entity.ABaseEntity;
import com.sena.servicesecurity.IRepository.IBaseRepository;
import com.sena.servicesecurity.IService.IBaseService;

/**
 * Abstract base service providing common CRUD operations for entities.
 * @param <T> The type of entity extending ABaseEntity.
 */
public abstract class ABaseService<T extends ABaseEntity> implements IBaseService<T> {

    /**
     * Retrieves the repository associated with the entity.
     * @return The repository associated with the entity.
     */
    protected abstract IBaseRepository<T, Long> getRepository();
    
    /**
     * Retrieves all entities.
     * @return A list of all entities.
     * @throws Exception If an error occurs while retrieving the entities.
     */
    @Override
    public List<T> all() throws Exception {
        return getRepository().findAll();
    }

    /**
     * Retrieves all entities with state set to true.
     * @return A list of entities with state set to true.
     * @throws Exception If an error occurs while retrieving the entities.
     */
    @Override
    public List<T> findByStateTrue() throws Exception {
        return getRepository().findAll();
    }

    /**
     * Retrieves an entity by its ID.
     * @param id The ID of the entity to retrieve.
     * @return An Optional containing the entity, or empty if not found.
     * @throws Exception If an error occurs while retrieving the entity.
     */
    @Override
    public Optional<T> findById(Long id) throws Exception {
        Optional<T> op = getRepository().findById(id);

        if (op.isEmpty()) {
            throw new Exception("Registro no encontrado");
        }   
        return op;
    }

    /**
     * Saves an entity.
     * @param entity The entity to save.
     * @return The saved entity.
     * @throws Exception If an error occurs while saving the entity.
     */
    @Override
    public T save(T entity) throws Exception {
        try {
            entity.setCreatedAt(LocalDateTime.now());
            entity.setCreatedBy((long)1); //Cuanto esté el loggin, se debe enviar el ID del usuario con Auth
            return getRepository().save(entity);
        } catch (Exception e) {
            // Captura la excepción
            throw new Exception("Error al guardar la entidad: " + e.getMessage());
        }
    }

    /**
     * Updates an existing entity by its ID.
     * @param id The ID of the entity to update.
     * @param entity The updated entity.
     * @throws Exception If an error occurs while updating the entity.
     */
    @Override
    public void update(Long id, T entity) throws Exception {
        Optional<T> op = getRepository().findById(id);

        if (op.isEmpty()) {
            throw new Exception("Registro no encontrado");
        } else if (op.get().getDeletedAt() != null) {
            throw new Exception("Registro inhabilitado");
        }

        T entityUpdate = op.get();

        String[] ignoreProperties = { "id", "createdAt", "deletedAt", "createdBy", "deletedBy" };
        BeanUtils.copyProperties(entity, entityUpdate, ignoreProperties);
        entityUpdate.setUpdatedAt(LocalDateTime.now());
        entityUpdate.setUpdatedBy((long)1); //Cuanto esté el loggin, se debe enviar el ID del usuario con Auth
        getRepository().save(entityUpdate);
    }

    /**
     * Deletes an entity by its ID.
     * @param id The ID of the entity to delete.
     * @throws Exception If an error occurs while deleting the entity.
     */
    @Override
    public void delete(Long id) throws Exception {
        Optional<T> op = getRepository().findById(id);

        if (op.isEmpty()) {
            throw new Exception("Registro no encontrado");
        }

        T entityUpdate = op.get();
        entityUpdate.setDeletedAt(LocalDateTime.now());
        entityUpdate.setDeletedBy((long)1); //Cuanto esté el loggin, se debe enviar el ID del usuario con Auth

        getRepository().save(entityUpdate);
    }
    
 
/*
    public List<IListDto> convertToIGenericDto(List<Object[]> results) {
        List<IListDto> dtos = new ArrayList<>();
        for (Object[] result : results) {
            // Variables para los campos comunes
            Long id = (Long) result[0];
            boolean state = (boolean) result[1];
            Optional<String> name = Optional.ofNullable((String) result[2]);
            Optional<String> description = Optional.ofNullable((String) result[3]);

            // Variables específicas para cada tabla
            Optional<String> route = Optional.empty();
            Optional<String> address = Optional.empty();
            Optional<String> dateOfBirth = Optional.empty();
            Optional<String> email = Optional.empty();
            Optional<String> firstName = Optional.empty();
            Optional<String> gender = Optional.empty();
            Optional<String> lastName = Optional.empty();
            Optional<String> phone = Optional.empty();

            // Comprueba la longitud del resultado para cada tabla y asigna los valores correspondientes
            if (result.length >= 5) {
                route = Optional.ofNullable((String) result[4]); // Campo específico para la tabla user
            }
            if (result.length >= 6) {
                address = Optional.ofNullable((String) result[5]); // Campo específico para la tabla person
            }
            if (result.length >= 7) {
                dateOfBirth = Optional.ofNullable((String) result[6]); // Campo específico para la tabla person
            }
            if (result.length >= 8) {
                email = Optional.ofNullable((String) result[7]); // Campo específico para la tabla person
            }
            if (result.length >= 9) {
                firstName = Optional.ofNullable((String) result[8]); // Campo específico para la tabla person
            }
            if (result.length >= 10) {
                gender = Optional.ofNullable((String) result[9]); // Campo específico para la tabla person
            }
            if (result.length >= 11) {
                lastName = Optional.ofNullable((String) result[10]); // Campo específico para la tabla person
            }
            if (result.length >= 12) {
                phone = Optional.ofNullable((String) result[11]); // Campo específico para la tabla person
            }

            // Hacer las variables final o efectivamente final
            Optional<String> routeFinal = route;
            Optional<String> addressFinal = address;
            Optional<String> dateOfBirthFinal = dateOfBirth;
            Optional<String> emailFinal = email;
            Optional<String> firstNameFinal = firstName;
            Optional<String> genderFinal = gender;
            Optional<String> lastNameFinal = lastName;
            Optional<String> phoneFinal = phone;

            // Crear el IListDto correspondiente solo si todos los campos requeridos no son nulos
            if (id != null && name.isPresent() && description.isPresent() && route.isPresent() && address.isPresent() && dateOfBirth.isPresent() && email.isPresent() && firstName.isPresent() && gender.isPresent() && lastName.isPresent() && phone.isPresent()) {
                IListDto dto = new IListDto() {
                    @Override
                    public Long getId() {
                        return id;
                    }

                    @Override
                    public Boolean getState() {
                        return state;
                    }

                    @Override
                    public String getName() {
                        return name.get();
                    }

                    @Override
                    public String getDescription() {
                        return description.get();
                    }

                    @Override
                    public String getRoute() {
                        return routeFinal.get();
                    }

                    @Override
                    public String getAddress() {
                        return addressFinal.get();
                    }

                    @Override
                    public String getDateOfBirth() {
                        return dateOfBirthFinal.get();
                    }

                    @Override
                    public String getEmail() {
                        return emailFinal.get();
                    }

                    @Override
                    public String getFirstName() {
                        return firstNameFinal.get();
                    }

                    @Override
                    public String getGender() {
                        return genderFinal.get();
                    }

                    @Override
                    public String getLastName() {
                        return lastNameFinal.get();
                    }

                    @Override
                    public String getPhone() {
                        return phoneFinal.get();
                    }
                };

                dtos.add(dto);
            }
        }
        return dtos;
    }

    // Método para filtrar las propiedades nulas antes de la serialización del objeto JSON
    public static String filterNullProperties(Object object) throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        return mapper.writeValueAsString(object);
    }
    */
    
    
    
    public List<IListDto> convertToIGenericDto(List<Object[]> results) {
        List<IListDto> dtos = new ArrayList<>();
        
        for (Object[] result : results) {
            
        	if (result.length == 5) {
            	
                IModuleViewDto dto = convertToIModuleViewDto(result);
                dtos.add(dto);
                
            }else if (result.length == 7 ) {
                IPersonDto dto = convertPerson(result);
                dtos.add(dto);
            } else if (result.length ==6 ) {
                IUserDto dto = convertUser(result);
                dtos.add(dto);
            }else if (result.length ==4 ) {
                IRoleDto dto = convertRol(result);
                dtos.add(dto);
            }
            
        }
        return dtos;
    }

    private IModuleViewDto convertToIModuleViewDto(Object[] result) {
        Long id = (Long) result[0]; 
        boolean state = (boolean) result[1];
        Optional<String> name = Optional.ofNullable((String) result[2]); 
        Optional<String> description = Optional.ofNullable((String) result[3]); 
        Optional<String> route = Optional.ofNullable((String) result[4]); 

        return new IModuleViewDto() {
            @Override
            public Long getId() {
                return id;
            }

            @Override
            public Boolean getState() {
                return state;
            }

            @Override
            public String getName() {
                return name.orElse(null);
            }

            @Override
            public String getDescription() {
                return description.orElse(null);
            }

            @Override
            public String getRoute() {
                return route.orElse(null);
            }
        };
    }

    private IRoleDto convertRol(Object[] result) {
        Long id = (Long) result[0]; 
        boolean state = (boolean) result[1];
        Optional<String> name = Optional.ofNullable((String) result[2]);
        Optional<String> description = Optional.ofNullable((String) result[3]); 
        
        return new IRoleDto() {
            @Override
            public Long getId() {
                return id;
            }

            @Override
            public Boolean getState() {
                return state;
            }

            @Override
            public String getName() {
                return name.orElse(null);
            }

            @Override
            public String getDescription() {
                return description.orElse(null);
            }
        };
    }

    private IPersonDto convertPerson(Object[] result) {
        Long id = (Long) result[0]; 
        boolean state = (boolean) result[1]; 
        Optional<String> name = Optional.ofNullable((String) result[2]); 
        Optional<String> SegunNombre = Optional.ofNullable((String) result[3]);
        Optional<String> genero = Optional.ofNullable((String) result[4]); 
        
        Optional<String> telefono = Optional.ofNullable((String) result[5]); 
        
        Optional<String> aadress = Optional.ofNullable((String) result[6]); 
        
        
        return new IPersonDto() {
            @Override
            public Long getId() {
                return id;
            }

            @Override
            public Boolean getState() {
                return state;
            }

          		
			@Override
			public String getFirst_name() {
				// TODO Auto-generated method stub
				
				return name.orElse(null);
			}

			@Override
			public String getLast_name() {
				// TODO Auto-generated method stub
				return SegunNombre.orElse(null);
			}

			@Override
			public String getGender() {
				// TODO Auto-generated method stub
				return genero.orElse(null);
			}

			@Override
			public String getPhone() {
				// TODO Auto-generated method stub
				return telefono.orElse(null);
					
			}

			@Override
			public String getaddress() {
				// TODO Auto-generated method stub
				return aadress.orElse(null);
			}
        };
    }

    private IUserDto convertUser(Object[] result) {
        Long id = (Long) result[0]; 
        boolean state = (boolean) result[1];
        Optional<String> first_name = Optional.ofNullable((String) result[2]);
        Optional<String> last_name = Optional.ofNullable((String) result[3]); 
        Optional<String> email = Optional.ofNullable((String) result[3]); 
        
        
        return new IUserDto() {
            @Override
            public Long getId() {
                return id;
            }

            @Override
            public Boolean getState() {
                return state;
            }

          		

	
			@Override
			public String getPrimerNombre() {
				// TODO Auto-generated method stub
				return first_name.orElse(null);
			}

			@Override
			public String getSegundoNombre() {
				// TODO Auto-generated method stub
				return last_name.orElse(null);
			}

			@Override
			public String getEmail() {
				// TODO Auto-generated method stub
				return email.orElse(null);
			}
        };
    }

    
}

