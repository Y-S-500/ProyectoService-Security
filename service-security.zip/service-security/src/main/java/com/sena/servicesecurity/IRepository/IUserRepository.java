package com.sena.servicesecurity.IRepository;

import com.sena.servicesecurity.DTO.IUserDto;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.sena.servicesecurity.Entity.User;

@Repository
public interface IUserRepository extends IBaseRepository<User, Long>{

	@Query(value = " SELECT "
					+ " u.id,	"
					+ " u.username user, "
					+ " CONCAT(p.first_name,' ',p.last_name) personName, "
					+ " p.email personEmail, "
					+ " u.state "
					+ "FROM "
					+ "	user u "
					+ "    INNER JOIN person p ON p.id = u.person_id "
					+ "WHERE "
					+ "	u.username = :username AND "
					+ " u.password = :password  ", nativeQuery = true)
			Optional<IUserDto> getLogin(String username, String password);
	/*
	@Query(value = "SELECT id,state,username,password,created_at FROM service_security.user\r\n"
			+ "\r\n"
			+ "\r\n"
			+ "\r\n"
			+ "	WHERE \r\n"
			+ "			 deleted_at IS NULL ", nativeQuery = true)
	*/
	
	@Query(value = "SELECT  user.id,\r\n"
			+ " user.state, \r\n"
			+ "user.username user, \r\n"
			+ "person.first_name,\r\n"
			+ "	person.last_name, \r\n"
			+ "			 person.email\r\n"
			+ "			FROM \r\n"
			+ "				 service_security.user\r\n"
			+ "			INNER JOIN person  ON person.id = user.person_id", nativeQuery = true)
	List<Object[]> getListD();
}
