package com.sena.servicesecurity.IRepository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.sena.servicesecurity.Entity.ModuleRole;

@Repository
public interface IModuleRoleRepository extends IBaseRepository<ModuleRole, Long>{

		 
}
