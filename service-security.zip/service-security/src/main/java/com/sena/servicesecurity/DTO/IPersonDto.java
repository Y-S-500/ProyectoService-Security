package com.sena.servicesecurity.DTO;

public interface IPersonDto extends IListDto{


	String getFirst_name();
	String getLast_name();
	String getGender();
	String getPhone();
	String getaddress();
}
